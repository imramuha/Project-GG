<?php $__env->startSection('content'); ?>
<div class="container-fluid creation-form">

    <h2 class="mt-2 mb-5">Add a news article</h2>

    <form method="post" action="<?php echo e(route('news.store')); ?>" data-parsley-validate class="form-horizontal">
        <?php echo csrf_field(); ?>

        <div class="form-row mb-3">

            <div class="col">
                <strong>Title</strong>
                <input type="text" name="title" class="form-control">
            </div>

        </div>

        <div class="form-row">

            <div class="col">
                <strong>Text</strong>
                <textarea rows="5" type="text" type="text" name="text" class="form-control"></textarea>
            </div>
        </div>

        <div class="ln_solid mt-4">
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
        </div>

        <div class="form-group mt-5">
            <div class="float-left">
                <a href="<?php echo e(route('news.index')); ?>" class="btn btn-secondary btn-xs float-right"><i class="fa fa-chevron-left"></i> Back </a>
            </div>
            <div class="float-right">
                <input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">
                <button type="submit" class="btn btn-primary">Add</button>
            </div>
        </div>
    </form>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\imran\Desktop\Project-GG-master\laravel\resources\views\backoffice\news\news_create.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class='mt-2 mb-4'>
        <h2>Reviews</h2>
    </div>
    <div >
        <table id="datatable-buttons" class="table table-dark table-bordered">
            <thead class="thead-darklight">
                <tr>
                    <th>Id</th>
                    <th>Review</th>
                    <th>Score</th>
                    <th>Reviewer</th>
                    <th>Receiver</th>
                    <th>Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($review['id']); ?></td>
                    <td><?php echo e($review['comment']); ?></td>
                    <td><?php echo e($review['score']); ?></td>
                    <td><?php echo e($review['reviewer']->username); ?></td>
                    <td><?php echo e($review['user']->username); ?></td>
                    <td><?php echo e($review['created_at']); ?></td>
                    <td><a href="<?php echo e(route('reviews.show', $review->id)); ?>" class="btn btn-danger btn-xs"><i class="fa fa-pencil" title="Delete"></i>Delete</a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\imran\Desktop\Project-GG-master\laravel\resources\views\backoffice\reviews\review_show.blade.php ENDPATH**/ ?>
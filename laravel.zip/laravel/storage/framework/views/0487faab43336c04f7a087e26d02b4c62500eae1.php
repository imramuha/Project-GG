<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class='mt-2 mb-4'>
        <h2>News <a href="<?php echo e(route('news.create')); ?>" class="btn btn-primary btn-xs float-right"><i class="fa fa-plus"></i> Create New </a></h2>
    </div>
    <div>
        <table id="datatable-buttons" class="table table-dark table-bordered">
            <thead class="thead-darklight">
                <tr>
                    <th>ID</th>
                    <th>Title</th>
                    <th>Text</th>
                    <th>Creator</th>
                    <th>Created</th>
                    <th>Updated</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $newsItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($newsItem->id); ?></td>
                    <td><?php echo e($newsItem->title); ?></td>
                    <td><?php echo e($newsItem->text); ?></td>
                    <td><?php echo e($newsItem->user->username); ?></td>
                    <td><?php echo e($newsItem->created_at); ?></td>
                    <td><?php echo e($newsItem->updated_at); ?></td>
                    <td>
                        <?php if($userRole === 'Admin'): ?>
                        <a href="<?php echo e(route('news.edit', ['news' => $newsItem->id])); ?>" class="btn btn-success btn-xs"><i class="fa fa-pencil" title="Edit"></i>Edit</a>
                        <a href="<?php echo e(route('news.show', $newsItem->id)); ?>" class="btn btn-danger btn-xs"><i class="fa fa-pencil" title="Delete"></i>Delete</a>
                        <?php else: ?>
                        <a>Only accessible for ADMINS</a>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\imran\Desktop\Project-GG-master\laravel\resources\views\backoffice\news\news_show.blade.php ENDPATH**/ ?>
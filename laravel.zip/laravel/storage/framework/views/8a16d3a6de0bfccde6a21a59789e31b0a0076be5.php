<?php $__env->startSection('content'); ?>
<div class="container-fluid text-center ">
    <img class="mb-5 logo-img" src="<?php echo e(URL::asset('logo.svg')); ?>" alt="logo" width="100px" height="75px">
    <h1 class="h3 mt-1 font-weight-normal"><strong>a warm welcome back!</strong></h1>
    <p class="mb-3">another day, different cries</p>

    <form class="form-signin" method="POST" action="<?php echo e(route('login')); ?>">
        <?php echo csrf_field(); ?>
        <label for="email" class="sr-only" placeholder="Email address"><?php echo e(__('E-Mail Address')); ?></label>

        <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required autofocus placeholder="Email address">

        <?php if($errors->has('email')): ?>
        <span class="invalid-feedback text-white">
            <strong><?php echo e($errors->first('email')); ?></strong>
        </span>
        <?php endif; ?>

        <label for="password" class="sr-only"><?php echo e(__('Password')); ?></label>

        <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required placeholder="Password">

        <?php if($errors->has('password')): ?>
        <span class="invalid-feedback text-white">
            <strong><?php echo e($errors->first('password')); ?></strong>
        </span>
        <?php endif; ?>

        <button type="submit" class="btn btn-lg btn-outline-light btn-block mt-5">
            <?php echo e(__('Login')); ?>

        </button>

    </form>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\imran\Desktop\Project-GG-master\laravel\resources\views\auth\login.blade.php ENDPATH**/ ?>
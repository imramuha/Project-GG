<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class='mt-2 mb-4'>
        <h2>Reports</h2>
    </div>
    <div class="x_content">
        <table id="datatable-buttons" class="table table-dark table-bordered">
            <thead class="thead-darklight">
                <tr>
                    <th>ID</th>
                    <th>Report Type</th>
                    <th>Type ID</th>
                    <th>Reason</th>
                    <th>Reporter</th>
                    <th>Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($report->id); ?></td>
                    <td><?php echo e($report->type); ?></td>
                    <td><?php echo e($report->type_id); ?></td>
                    <td><?php echo e($report->reason); ?></td>
                    <td><?php echo e($report->user->username); ?></td>
                    <td><?php echo e($report->created_at); ?></td>
                    <td><a href="<?php echo e(route('reports.delete', $report->id )); ?>" class="btn btn-danger btn-xs"><i class="fa fa-pencil" title="Delete"></i>Delete</a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\imran\Desktop\Project-GG-master\laravel\resources\views\dashboard.blade.php ENDPATH**/ ?>
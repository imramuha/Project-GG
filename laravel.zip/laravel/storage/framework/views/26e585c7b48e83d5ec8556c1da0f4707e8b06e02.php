 <?php $__env->startSection('content'); ?>
<div class="container-fluid creation-form">
    <h2 class="mt-2 mb-5">Edit a User</h2>
    <form method="post" action="<?php echo e(route('users.update', $user->id)); ?>" data-parsley-validate class="form-horizontal">

        <div class="form-group<?php echo e($errors->has('username') ? ' has-error' : ''); ?>">

            <div class="form-row">

                <div class="col-5">
                    <label>Username</label>
                    <input type="text" value="<?php echo e(old( 'username', $user->username)); ?>" name="username" class="form-control">
                    <?php if($errors->has('username')): ?>
                    <span class="help-block"><?php echo e($errors->first('username')); ?> <br /></span>
                    <?php endif; ?>
                </div>

                <div class="col-5 mb-3 ml-auto">
                    <label>Email</label>
                    <input type="text" value="<?php echo e(old( 'email', $user->email)); ?>" name="email" class="form-control">
                    <?php if($errors->has('email')): ?>
                    <span class="help-block"><?php echo e($errors->first('email')); ?> <br /></span> <br />
                    <?php endif; ?>
                </div>

                <div class="col-5">
                    <label>Status</label>
                    <select id="inlineFormCustomSelect" class="form-control custom-select mr-sm-2" name="status_id">
                    <?php if($user->status): ?>
                        <option value="<?php echo e($user->status->id); ?>" selected>Current: <?php echo e($user->status->name); ?></option>
                        <?php else: ?>
                            <option value="" selected disabled>Select a role for this user</option>
                        <?php endif; ?>
                       <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($status->id); ?>">
                            <?php echo e($status->name); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($errors->has('status_id')): ?>
                    <span class="help-block"><?php echo e($errors->first('status_id')); ?> <br /></span> <br />
                    <?php endif; ?>
                </div>

                <div class="col-5 ml-auto">
                    <label>Role</label>
                    <select id="inlineFormCustomSelect" class="form-control custom-select mr-sm-2" name="role_id">
                        <?php if($user->role): ?>
                            <option value="<?php echo e($user->role->id); ?>" selected>Current: <?php echo e($user->role->name); ?></option>
                        <?php else: ?>
                            <option value="" selected disabled>Select a role for this user</option>
                        <?php endif; ?>
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($role->id); ?>">
                            <?php echo e($role->name); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php if($errors->has('role_id')): ?>
                    <span class="help-block"><?php echo e($errors->first('role_id')); ?> <br /></span> <br />
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class=" mt-5">
            <div class="float-left">
                <a href="<?php echo e(route('users.index')); ?>" class="btn btn-secondary danger btn-xs float-right"><i class="fa fa-chevron-left"></i> Back </a>
            </div>
            <div class="float-right">
                <input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">
                <input name="_method" type="hidden" value="PUT">
                <button type="submit" class="btn btn-success btn-xs">Update</button>
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\imran\Desktop\Project-GG-master\laravel\resources\views\backoffice\users\user_edit.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid creation-form">
    <h2 class="mt-2 mb-5">Update a Game</h2>

    <form method="post" action="<?php echo e(route('games.update', $game->id)); ?>" enctype="multipart/form-data" data-parsley-validate class="form-horizontal">

        <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">

            <div class="form-row mb-3">

                <div class="col-12">
                    <strong>Name</strong>
                    <input type="text" value="<?php echo e(old( 'game', $game->name)); ?>" name="name" class="form-control">
                    <?php if($errors->has('name')): ?>
                    <span class="help-block"><?php echo e($errors->first('game')); ?> <br /></span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="form-row">

                <div class="col-6">
                    <strong>Game Image</strong>
                    <input id="image" accept="image/*" type="file" class="form-control" name="image">
                </div>


                <div class="col-6 ml-auto">
                    <strong>Current Image</strong> <br>
                    <img src="data:image/jpeg;base64,<?php echo e($game->image); ?>" style="width: 100px; height: auto;" />
                </div>

            </div>

            <div class="mt-5">
                <div class="float-left">
                    <a href="<?php echo e(route('games.index')); ?>" class="btn btn-secondary btn-xs float-right"><i class="fa fa-chevron-left"></i> Back </a>
                </div>

                <div class="float-right">
                    <input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">
                    <input name="_method" type="hidden" value="PUT">
                    <button type="submit" class="btn btn-success">Update</button>
                </div>
            </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\imran\Desktop\Project-GG-master\laravel\resources\views\backoffice\games\game_edit.blade.php ENDPATH**/ ?>
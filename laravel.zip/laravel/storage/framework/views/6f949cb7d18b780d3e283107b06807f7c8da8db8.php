<?php $__env->startSection('content'); ?>
<div class="container-fluid creation-form">

    <h2 class="mt-2 mb-5">Confirm deletion of a User</h2>
    <p>Are you sure you want to delete the following User: <strong><?php echo e($user->username); ?></strong>?</strong></p>


    <div class="form-row mt-5">
        <div class=" col-6 float-left">
            <a href="<?php echo e(route('users.index')); ?>" class="btn btn-secondary btn-xs"><i class="fa fa-chevron-left"></i> Back </a>
        </div>
        <div class="col-6 float-right text-right">
            <form method="POST" action="<?php echo e(route('users.destroy', $user->id)); ?>">
                <input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">
                <input name="_method" type="hidden" value="DELETE">
                <button type="submit" class="btn btn-danger">Delete</button>
            </form>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\imran\Desktop\Project-GG-master\laravel\resources\views\backoffice\users\user_delete.blade.php ENDPATH**/ ?>
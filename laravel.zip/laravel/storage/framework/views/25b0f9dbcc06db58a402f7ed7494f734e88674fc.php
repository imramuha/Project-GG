<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class='mt-2 mb-4'>
            <h2 >Criteria <a href="<?php echo e(route('criteria.create')); ?>" class="btn btn-primary btn-xs float-right"><i class="fa fa-plus"></i> Create New </a></h2>
        </div>
        <div class="x_content">        
            <table id="datatable-buttons" class="table table-dark table-bordered">
                <thead class="thead-darklight">
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Games</th>
                        <th>Created</th>
                        <th>Updated</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $criteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $criterion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                        <tr>
                        <td><?php echo e($criterion->id); ?></td>
                            <td><?php echo e($criterion->name); ?></td>
                            <td>
                            <?php $__currentLoopData = $criterion->games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($game->name); ?>  
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                           
                            </td>
                            <td><?php echo e($criterion->created_at); ?></td>
                            <td><?php echo e($criterion->updated_at); ?></td>
                            <td>
            
                                    <a href="<?php echo e(route('criteria.edit', $criterion->id )); ?>" class="btn btn-success btn-xs"><i class="fa fa-pencil" title="Edit"></i>Edit</a>
                                    <a href="<?php echo e(route('criteria.show', $criterion->id )); ?>" class="btn btn-danger btn-xs"><i class="fa fa-pencil" title="Delete"></i>Delete</a>
                            </td>
                        </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\imran\Desktop\Project-GG-master\laravel\resources\views\backoffice\criteria\criterion_show.blade.php ENDPATH**/ ?>
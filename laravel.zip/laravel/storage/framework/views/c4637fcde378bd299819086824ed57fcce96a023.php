<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class='mt-2 mb-4'>
        <h2>Games <a href="<?php echo e(route('games.create')); ?>" class="btn btn-primary btn-xs float-right"><i class="fa fa-plus"></i> New Game </a></h2>
    </div>
    <div >
        <table id="datatable-buttons" class="table table-dark table-bordered">
            <thead class="thead-darklight">
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Image</th>
                    <th>Criteria</th>
                    <th>Created at</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($game->id); ?></td>
                    <td><img src="data:image/jpeg;base64,<?php echo e($game->image); ?>" style="width: 100px; height: autopx;" /></td>
                    <td><?php echo e($game->name); ?></td>
                    <td><?php $__currentLoopData = $game->criteria; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $criterion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        [<?php echo e($criterion->name); ?>]
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td><?php echo e($game->created_at); ?></td>
                    <td>
                        <a href="<?php echo e(route('games.edit', ['game' => $game->id])); ?>" class="btn btn-success btn-xs"><i class="fa fa-pencil" title="Edit"></i>Edit</a>
                        <a href="<?php echo e(route('games.show', $game->id)); ?>" class="btn btn-danger btn-xs"><i class="fa fa-trash-o" title="Delete"></i>Delete </a></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\imran\Desktop\Project-GG-master\laravel\resources\views\backoffice\games\game_show.blade.php ENDPATH**/ ?>
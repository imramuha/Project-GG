<?php $__env->startSection('content'); ?>
<div class="container-fluid creation-form">

    <h2 class="mt-2 mb-5">Add a new game</h2>

    <form method="post" action="<?php echo e(route('games.store')); ?>" data-parsley-validate enctype="multipart/form-data" class="form-horizontal form-label-left">
        <?php echo csrf_field(); ?>

        <div class="form-row">

            <div class="col-5">
                <strong>Name</strong>
                <input type="text" name="name" class="form-control">
            </div>
            <div class="col-6 ml-auto">
                <strong>Game Image</strong>
                    <input id="image" accept="image/*" type="file" class="form-control" name="image">
            </div>
        </div>

        <div class="mt-4">
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
        </div>

        <div class="form-group mt-5">
            <div class="float-left">
                <a href="<?php echo e(route('games.index')); ?>" class="btn btn-secondary btn-xs float-right"><i class="fa fa-chevron-left"></i> Back </a>
            </div>
            <div class="float-right">
                <input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">
                <button type="submit" class="btn btn-primary">Add</button>
            </div>
        </div>
    </form>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\imran\Desktop\Project-GG-master\laravel\resources\views\backoffice\games\game_create.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<div class="container no-access">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header no-access-header">UNAUTHORIZED</div>
                <div class=" no-access-body card-body">
                    You have to be an ADMIN or a MODERATOR to be able to log into the backoffice!
                </div>
                <a class="nav-link" href="<?php echo e(route('login')); ?>">GO BACK</a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\imran\Desktop\Project-GG-master\laravel\resources\views\auth\no-access\access.blade.php ENDPATH**/ ?>
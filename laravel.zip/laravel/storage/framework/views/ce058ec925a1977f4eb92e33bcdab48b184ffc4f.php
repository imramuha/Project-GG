<?php $__env->startSection('content'); ?>
<div class="container-fluid creation-form">

    <h2 class="mt-2 mb-5">Add a Criterion</h2>


    <form method="post" action="<?php echo e(route('criteria.store')); ?>" data-parsley-validate class="form-horizontal form-label-left">
        <?php echo csrf_field(); ?>

        <div class="form-row">

            <div class="col-5">
                <strong>Name</strong>
                <input type="text" name="name" class="form-control">
            </div>

            <div class="col-6 ml-auto">
                <strong>Game</strong>
                <select id="inlineFormCustomSelect" class="form-control custom-select mr-sm-2" name="game_id">
                    <option value="" selected disabled>Choose the game you want it to attach...</option>
                    <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($game->id); ?>">
                        <?php echo e($game->name); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

        <div class="mt-4">
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
        </div>

        <div class="form-group mt-5">
            <div class="float-left">
                <a href="<?php echo e(route('criteria.index')); ?>" class="btn btn-secondary btn-xs float-right"><i class="fa fa-chevron-left"></i> Back </a>
            </div>
            <div class="float-right">
                <input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">
                <button type="submit" class="btn btn-primary">Add</button>
            </div>
        </div>
    </form>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\imran\Desktop\Project-GG-master\laravel\resources\views\backoffice\criteria\criterion_create.blade.php ENDPATH**/ ?>
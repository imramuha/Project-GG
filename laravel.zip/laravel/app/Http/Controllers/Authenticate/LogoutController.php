<?php

namespace App\Http\Controllers\Authenticate;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class LogoutController extends Controller
{
    //    // siging
    public function __invoke () {
        auth()->logout();

        return response()->json(['message' => 'Successfully logged out']);
    }
}
